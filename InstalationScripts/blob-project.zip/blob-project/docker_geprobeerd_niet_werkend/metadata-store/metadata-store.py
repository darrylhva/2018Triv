from flask import Flask, jsonify, request
from flask_pymongo import PyMongo
from pymongo import MongoClient
import bson
from bson.json_util import dumps, loads

app = Flask(__name__)

app.config['MONGO_DBNAME'] = 'metadata-store'
app.config['MONGO_URI'] = 'mongodb://localhost/metadata-store'

mongo = PyMongo(app)

@app.route('/metadata/all', methods=['GET'])
def get_all_metadata():
	metadata = mongo.db.metadata

	output = []

	for q in metadata.find():
		size = len(bson.BSON.encode(q))
		output.append({'Metadata ID' : q['id_metadata'], 'Title' : q['title'], 'Owner' : q['owner'], 'Owner Group' : q['owner_group'],  'Create' : q['create_date'], 'Last Modified' : q['modified_date'], 'Size' : (str(size) + ' kb')})

	return jsonify({'Alle metadata entries' : output})


@app.route('/metadata/id/<id_metadata>', methods=['GET'])
def get_metadata_by_id(id_metadata):
	metadata = mongo.db.metadata

	q = metadata.find_one({'id_metadata' : id_metadata})
	size = len(bson.BSON.encode(q))
	output = {'ID' : q['id_metadata'], 'Title' : q['title'], 'Owner' : q['owner'], 'Owner Group' : q['owner_group'],  'Create' : q['create_date'], 'Last Modified' : q['modified_date'], 'Size' : (str(size) + ' kb')}

	return jsonify({'Resultaten voor één metadata ID' : output})

@app.route('/metadata/owners/<owner>', methods=['GET'])
def get_owner_metadata(owner):
	metadata = mongo.db.metadata
	output = []

	for q in metadata.find({"owner": owner}):
		size = len(bson.BSON.encode(q))
		output.append({'Metadata ID' : q['id_metadata'], 'Title' : q['title'], 'Owner' : q['owner'], 'Owner Group' : q['owner_group'],  'Create' : q['create_date'], 'Last Modified' : q['modified_date'], 'Size' : (str(size) + ' kb')})

	return jsonify({'Resultaten voor enkele owner' : output})


@app.route('/metadata/owner_groups/<owner_group>', methods=['GET'])
def get_owner_group_metadata(owner_group):
	metadata = mongo.db.metadata
	output = []

	for q in metadata.find({"owner_group": owner_group}):
		size = len(bson.BSON.encode(q))
		output.append({'Metadata ID' : q['id_metadata'], 'Title' : q['title'], 'Owner' : q['owner'], 'Owner Group' : q['owner_group'],  'Create' : q['create_date'], 'Last Modified' : q['modified_date'], 'Size' : (str(size) + ' kb')})

	return jsonify({'Resultaten voor alle data voor enkele owner group' : output})


@app.route('/metadata/titles/<title>', methods=['GET'])
def get_title_metadata(title):
	metadata = mongo.db.metadata
	output = []

	metadata.create_index([('title', 'text')])

	for q in metadata.find({"$text": {"$search": title}}):
		size = len(bson.BSON.encode(q))
		output.append({'Metadata ID' : q['id_metadata'], 'Title' : q['title'], 'Owner' : q['owner'], 'Owner Group' : q['owner_group'],  'Create' : q['create_date'], 'Last Modified' : q['modified_date'], 'Size' : (str(size) + ' kb')})

	return jsonify({'Resultaten voor titels' : output})



@app.route('/metadata', methods=['POST'])
def add_metadata():

	metadata = mongo.db.metadata

	id_metadata = request.json['id_metadata']
	title = request.json['title']
	owner = request.json['owner']
	owner_group = request.json['owner_group']
	create_date = request.json['create_date']
	modified_date = request.json['modified_date']

	metadata_id = metadata.insert({'id_metadata': id_metadata, 'title' : title, 'owner' : owner, 'owner_group' : owner_group, 'create_date' : create_date, 'modified_date' : modified_date})
	new_metadata = metadata.find_one({'_id' : metadata_id})

	##################### HIER WORDT DE SIZE in  BYTES GEVRAAGD VAN DE METADATA ############################
	db = MongoClient('localhost', 27017)
	doc = db['metadata-store']['metadata'].find_one({'id_metadata': id_metadata})
	metadata_size = (len(bson.BSON.encode(doc)))

	############################## OUTPUT WORDT KLAARGEMAAKT ########################################
	output = {'ID Metadata' : new_metadata['id_metadata'], 'title' : new_metadata['title'], 'owner' : new_metadata['owner'], 'owner_group' : new_metadata['owner_group'], 'create_date' : new_metadata['create_date'], 'modified_date' : new_metadata['modified_date'], 'Size' : (str(metadata_size) + ' kb')}

	return jsonify(output)

if __name__ == '__main__':
	app.run(host="0.0.0.0", port=3000, debug=True)
