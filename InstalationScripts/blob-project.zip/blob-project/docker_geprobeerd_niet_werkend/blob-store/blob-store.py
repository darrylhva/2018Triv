from flask import Flask, jsonify, request
from flask_pymongo import PyMongo
from pymongo import MongoClient
import pymongo
import bson

app = Flask(__name__)

app.config['MONGO_DBNAME'] = 'blob-store'
app.config['MONGO_URI'] = 'mongodb://localhost/blob-store'

mongo = PyMongo(app)

@app.route('/blobs/all', methods=['GET'])
def get_all_blobs():
    blob = mongo.db.blobs

    output = []

    for q in blob.find():
        size = len(bson.BSON.encode(q))
        output.append({'ID Blob' : q['id_blob'], 'ID Metadata': q['id_metadata'], 'Taal' : q['language'], 'Inhoud' : q['text'], 'Size' : (str(size) + ' kb')})

    return jsonify({'result' : output})

@app.route('/blobs/id/<id_blob>', methods=['GET'])
def get_one_blob(id_blob):
    blob = mongo.db.blobs

    q = blob.find_one({'id_blob': id_blob})
    size = len(bson.BSON.encode(q))
    output = ({'ID Blob' : q['id_blob'], 'ID Metadata': q['id_metadata'], 'Taal' : q['language'], 'Inhoud' : q['text'], 'Size' : (str(size) + ' kb')})

    return jsonify({'result' : output})


@app.route('/blobs/metadata/<id_metadata>', methods=['GET'])
def get_all_blobs_from_one_metadata(id_metadata):
    blob = mongo.db.blobs

    output = []

    for q in blob.find({'id_metadata': id_metadata}):
        size = len(bson.BSON.encode(q))
        output.append({'ID Blob' : q['id_blob'], 'ID Metadata': q['id_metadata'], 'Taal' : q['language'], 'Inhoud' : q['text'], 'Size' : (str(size) + ' kb')})

    return jsonify({'result' : output})


@app.route('/blobs/inhoud/<inhoud>', methods=['GET'])
def get_all_blobs_from_inhoud(inhoud):
    blob = mongo.db.blobs

    blob.create_index([('text', 'text')])

    output = []


    for q in (blob.find({"$text": {"$search": inhoud}})):
        size = len(bson.BSON.encode(q))
        output.append({'ID Blob' : q['id_blob'], 'ID Metadata': q['id_metadata'], 'Taal' : q['language'], 'Inhoud' : q['text'], 'Size' : (str(size) + ' kb')})

    return jsonify({'result' : output})

@app.route('/blob', methods=['POST'])
def add_blob():
    blob = mongo.db.blobs

    id_metadata = request.json['id_metadata']
    id_blob = request.json['id_blob']
    language = request.json['language']
    text = request.json['text']

    blob_id = blob.insert({'id_blob': id_blob, 'id_metadata' : id_metadata, 'language' : language, 'text' : text})
    new_blob = blob.find_one({'_id' : blob_id})

    ##################### HIER WORDT DE SIZE in  BYTES GEVRAAGD VAN DE METADATA ############################
    db = MongoClient('localhost', 27017)
    doc = db['blob-store']['blobs'].find_one({'id_blob': id_blob})
    blob_size = (len(bson.BSON.encode(doc)))

    ############################## OUTPUT WORDT KLAARGEMAAKT ########################################

    output = {'ID Blob' : new_blob['id_blob'], 'ID Metadata' : new_blob['id_metadata'], 'Taal' : new_blob['language'], 'Text' : new_blob['text'], 'Blob size in bytes' : blob_size}

    return jsonify(output)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=4000, debug=True)
