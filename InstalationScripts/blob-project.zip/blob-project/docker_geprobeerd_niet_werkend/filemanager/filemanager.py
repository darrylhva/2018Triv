from flask import Flask, jsonify, request, render_template
import uuid, random # to gen node uids
import requests
import json
from datetime import datetime
import bson

# Globale variables
url_metadata = 'http://10.0.0.30:3000/metadata'
url_blob = 'http://10.0.0.40:4000/blob'
headers = {'content-type': 'application/json'}

# Globale tijd en datum functie
def huidige_datum_tijd():
    i = datetime.now()
    return i.strftime('%d-%m-%Y %H:%M:%S')

app = Flask(__name__)

#Functie om een random ID te genereren.
uuidCount=0
def Uuid():
    global uuidCount
    uuidCount += 1
    random.seed(uuidCount)
    a = '%32x' % random.getrandbits(128)
    rd = a[:12] + '4' + a[13:16] + 'a' + a[17:]
    return uuid.UUID(rd)

@app.route('/', methods=['GET'])
def home_page_info():
    return "Welkom tot de Filemanager RESTful API voor het Blob project" \
           "Hogeschool van Amsterdam" \
           "Gebruik van de filemanager API" \
           "GET:" \
           "Mogelijke links/acties:" \
           "    * /metadata/id/&#60id_metadata&#62            -- Hier kan men zoeken op metadata IDs in de metadata store" \
           "    * /blobs/id/&#60id_blob&#62                   -- Hier kan men zoeken op blob IDs in de blob store" \
           "    * /blobs/metadata/&#60id_metadata&#62         -- Hier kan men zoeken op metadata IDs in de blob store" \
           "    * /blobs/inhoud/&#60inhoud&#62                -- Hier kan men zoeken inhoud in de blob store" \
           "    * /metadata/owners/&#60owner&#62              -- Hier kan men zoeken op owner in de metadata store" \
           "    * /metadata/owner_groups/&#60owner_group&#62  -- Hier kan men zoeken op owners group in de metadata store" \
           "    * /metadata/titles/&#60title&#62              -- Hier kan men zoeken op titels in de metadata store" \
           "    * /metadata/all                         -- Hier krijgt men de volledige metadata DB te zien" \
           "    * /blobs/all                            -- Hier krijgt men de volledige metadata DB te zien" \
           "POST:" \
           "Mogelijke links/acties:" \
           "    * /newblob -- Hier kan men een blob invoeren met metadata" \
           "        Data die nodig is om te kunnen POSTen:" \
           "            - owner                         -- Is een string, naam van de eigenaar" \
           "            - owner_group                   -- Is een string, naam van de groep" \
           "            - title                         -- Is een string, titel van het doc" \
           "            - language                      -- Is een string maar er zijn beperkingen:" \
           "                * Toegestande entries:" \
           "                     da or danish" \
           "                     nl or dutch" \
           "                     en or english" \
           "                     fi or finnish" \
           "                     fr or french" \
           "                     de or german" \
           "                     hu or hungarian" \
           "                     it or italian" \
           "                     nb or norwegian" \
           "                     pt or portuguese" \
           "                     ro or romanian" \
           "                     ru or russian" \
           "                     es or spanish" \
           "                     sv or swedish" \
           "                     tr or turkish" \
           "            - text                          -- Is de text van de blob"










@app.route('/metadata/id/<id_metadata>', methods=['GET'])
def get_metadata_by_id(id_metadata):
    get_all = requests.get('http://10.0.0.30:3000/metadata/id/' + id_metadata)
    res_metadata = get_all.json()
    return jsonify({'Alle metadata': res_metadata})


@app.route('/blobs/id/<id_blob>', methods=['GET'])
def get_blob_by_id(id_blob):
    get_all = requests.get('http://10.0.0.40:4000/blobs/id/' + id_blob)
    res_metadata = get_all.json()
    return jsonify({'Alle Blobs': res_metadata})


@app.route('/blobs/metadata/<id_metadata>', methods=['GET'])
def get_blob_by_metadataid(id_metadata):
    get_all = requests.get('http://10.0.0.40:4000/blobs/metadata/' + id_metadata)
    res_metadata = get_all.json()
    return jsonify({'Alle Blobs': res_metadata})


@app.route('/blobs/inhoud/<inhoud>', methods=['GET'])
def get_blob_by_inhoud(inhoud):
    get_all = requests.get('http://10.0.0.40:4000/blobs/inhoud/' + inhoud)
    res_metadata = get_all.json()
    return jsonify({'Alle Blobs': res_metadata})


@app.route('/metadata/owners/<owner>', methods=['GET'])
def get_metadata_by_owner(owner):
    get_all = requests.get('http://10.0.0.30:3000/metadata/owners/' + owner)
    res_metadata = get_all.json()
    return jsonify({'Alle metadata': res_metadata})


@app.route('/metadata/owner_groups/<owner_group>', methods=['GET'])
def get_metadata_by_owner_group(owner_group):
    get_all = requests.get('http://10.0.0.30:3000/metadata/owner_groups/' + owner_group)
    res_metadata = get_all.json()
    return jsonify({'Alle metadata': res_metadata})


@app.route('/metadata/titles/<title>', methods=['GET'])
def get_metadata_by_title(title):
    get_all = requests.get('http://10.0.0.30:3000/metadata/titles/' + title)
    res_metadata = get_all.json()
    return jsonify({'Alle metadata': res_metadata})

@app.route('/metadata/all', methods=['GET'])
def get_all_metadata():
    get_all = requests.get('http://10.0.0.30:3000/metadata/all')
    res_metadata = get_all.json()
    return jsonify({'Alle metadata': res_metadata})


@app.route('/blobs/all', methods=['GET'])
def get_all_blobs():
    get_all = requests.get('http://10.0.0.40:4000/blobs/all')
    res_metadata = get_all.json()
    return jsonify({'Alle metadata': res_metadata})

@app.route('/newblob', methods=['POST'])
def new_blob():

    ############################HIER WORDEN DE ID's GEGENEREERD ###############################################
    id_metadata = str(Uuid())
    id_blob = str(Uuid())

    ############################HIER BEGINT DE GEDEELTE VOOR DE BLOB #######################################

    language = request.json['language']
    text = request.json['text']

    payload_blob = {'id_blob': id_blob, 'id_metadata' : id_metadata, 'language' : language, 'text' : text}
    post_naar_blobstore = requests.post(url_blob, data=json.dumps(payload_blob), headers=headers)

    res_blob = post_naar_blobstore.json()

    ############################HIER BEGINT DE GEDEELTE VOOR DE Metadata #######################################


    title = request.json['title']
    owner = request.json['owner']
    owner_group = request.json['owner_group']
    create_date = huidige_datum_tijd()
    modified_date = huidige_datum_tijd()

    payload_metadata = {'id_metadata': id_metadata, 'title': title, 'owner': owner, 'owner_group': owner_group, 'create_date': create_date, 'modified_date': modified_date}
    post_naar_metadatastore = requests.post(url_metadata, data=json.dumps(payload_metadata), headers=headers)

    res_metadata = post_naar_metadatastore.json()

    ############################HIER WORDT DE RESPONS SAMENGEVOEGD #######################################

    return jsonify({'Metadata invoer': res_metadata, 'Blob invoer': res_blob})






#Hiermee runt ie de server
if __name__ == '__main__':
	app.run(host="0.0.0.0", port=5000, debug=True)